"""
Dust attenuation laws: family comparison across UV to near-IR
==============================================================

Dust attenuation laws encode how interstellar dust preferentially absorbs
short-wavelength (UV) starlight relative to optical/IR. The wavelength
dependence is empirically calibrated to extinction measurements in the Milky Way
(Cardelli+1989), Large/Small Magellanic Clouds (Pei 1992), and starburst
galaxies (Calzetti+2000, Kriek+Conroy 2013).

This gallery overlays six textbook attenuation laws as A_λ/A_V vs wavelength
on a log-log scale spanning 1000–30000 Å (far-UV to near-IR). The prominent
2175 Å bump (characteristic of Milky Way dust) appears in some laws but not
others. UV slopes steepen towards the Calzetti and Kriek+Conroy families
(star-forming galaxies), whereas SMC shows the steepest UV rise and no bump.
At fixed τ_V = 1 (representing moderate dust column density), each law sets
the color distribution of an attenuated SED.

References:
- Calzetti et al. 2000, ApJ, 533, 682 (starburst attenuation)
- Cardelli, Clayton & Mathis 1989, ApJ, 345, 245 (MW extinction)
- Charlot & Fall 2000, ApJ, 539, 718 (power-law families)
- Kriek & Conroy 2013, ApJL, 775, L16 (flexible Calzetti+bump+slope)
- Pei 1992, ApJ, 395, 130 (SMC, LMC extinction)
"""

import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"  # suppress XLA/PjRt C++ INFO+WARNING logs

import warnings

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np

from tengri.analysis.plotting import setup_style
from tengri.dust import list_laws

setup_style()
warnings.filterwarnings("ignore", message=".*BakedInBackend.*")

# Wavelength grid: 1000–30000 Å on log scale
wave_aa = jnp.logspace(3.0, 4.477, 1500)

# Get the curated headline attenuation laws as a dict of callables.
# Each law is pre-parameterized to canonical "nominal" values (e.g. tau_V=1).
laws = list_laws(headline=True)

# ────────────────────────────────────────────────────────────────────────────
# Plot: A_λ/A_V vs wavelength on log-log scale
# ────────────────────────────────────────────────────────────────────────────

fig, ax = plt.subplots(figsize=(7.0, 5.0))

# Color palette: six distinct hues for visual separation
colors = {
    "Calzetti+2000": "#1f77b4",
    "Charlot & Fall (slope=-0.7)": "#ff7f0e",
    "Cardelli+1989 (MW, Rv=3.1)": "#2ca02c",
    "SMC (Gordon+2003)": "#d62728",
    "Kriek & Conroy 2013": "#9467bd",
    "Salim+2018": "#8c564b",
}

for label, fn in laws.items():
    # Evaluate the attenuation curve k(λ) at all wavelengths
    k_wave = fn(wave_aa)

    # Convert to numpy for plotting
    ax.loglog(np.array(wave_aa), np.array(k_wave), lw=2.2, label=label, color=colors[label])

# Mark the 2175 Å UV bump for reference (appears in MW-type curves)
ax.axvline(2175.0, color="gray", lw=1.0, ls=":", alpha=0.5)
ax.text(2175.0, 0.3, "2175 Å bump", fontsize=8, ha="center", color="gray", alpha=0.6)

# Mark the V-band normalization point (5500 Å)
ax.axvline(5500.0, color="black", lw=0.8, ls="--", alpha=0.3)
ax.text(5500.0, 0.15, "V-band norm", fontsize=8, ha="center", color="black", alpha=0.4)

# Axis labels and limits
ax.set_xlim(1000, 30000)
ax.set_ylim(0.1, 10)
ax.set_xlabel(r"Wavelength [$\mathrm{\AA}$]", fontsize=11)
ax.set_ylabel(r"Attenuation curve $k(\lambda) = A_\lambda / A_V$", fontsize=11)

# Legend: position outside the plot area
ax.legend(loc="upper right", frameon=True, fontsize=9)

fig.tight_layout()
plt.savefig("plot_attenuation_law_family.png", dpi=150, bbox_inches="tight")
print("Saved: plot_attenuation_law_family.png")
