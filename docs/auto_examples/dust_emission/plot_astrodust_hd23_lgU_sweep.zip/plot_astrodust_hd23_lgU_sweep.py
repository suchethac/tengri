r"""
Hensley & Draine 2023 Astrodust+PAH: log U sweep
=================================================

Sweep ionization parameter across the published :math:`[-3, +6]` range of the
Hensley & Draine 2023 grid. Shows FIR peak shift toward shorter wavelengths
and rising MIR PAH features as radiation field intensifies.
"""

import warnings

import matplotlib.pyplot as plt
import numpy as np

from tengri import data_path
from tengri.analysis.plotting import setup_style
from tengri.components.dust.astrodust_hd23 import load_astrodust_hd23_or_raise

setup_style()
warnings.filterwarnings("ignore", message=".*BakedInBackend.*")
warnings.filterwarnings("ignore", message=".*deprecated.*")

tpl = load_astrodust_hd23_or_raise(data_path("astrodust_templates.h5"))
wave_um = np.asarray(tpl.wavelength_um)
lgU = np.asarray(tpl.lgU)
L_nu_total = np.asarray(tpl.L_nu_total)

c_cgs = 2.99792458e10
lam_cm = wave_um * 1.0e-4
li_um = L_nu_total * c_cgs / (4.0 * np.pi * lam_cm[None, :])

fig, ax = plt.subplots(figsize=(7.0, 5.0))
cmap = plt.get_cmap("viridis")
targets = [-3.0, -2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
for k, tg in enumerate(targets):
    i = int(np.argmin(np.abs(lgU - tg)))
    ax.plot(
        wave_um,
        li_um[i],
        color=cmap(k / max(1, len(targets) - 1)),
        lw=1.4,
        label=rf"$\log_{{10}} U={lgU[i]:+.1f}$",
    )
ax.set(
    xscale="log",
    yscale="log",
    xlabel=r"$\lambda\ [\mu\mathrm{m}]$",
    ylabel=r"$\lambda I_\lambda / N_{\rm H}\ [\mathrm{erg\,s^{-1}\,sr^{-1}\,H^{-1}}]$",
    xlim=(1.0, 1.0e3),
    ylim=(1.0e-29, 1.0e-18),
)
ax.legend(loc="lower right", frameon=False, fontsize=9, ncol=2)
fig.tight_layout()
fig.savefig("plot_astrodust_hd23_lgU_sweep.png", dpi=150, bbox_inches="tight")
