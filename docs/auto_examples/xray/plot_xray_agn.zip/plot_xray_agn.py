"""
AGN X-ray coronae: luminosity sequence
======================================

AGN coronae are compact hot regions where the hard X-ray power law (photon
index ~1.7–2.0) is produced via Compton up-scattering of seed UV photons by
hot electrons. ``xray_agn_corona`` models the primary continuum as a cut-off
power-law normalised through the α_ox–L_2500 relation
(Lusso & Risaliti 2016), then attenuated by the
``zphabs(N_H) × cabs(N_H)`` line-of-sight obscurer with a 1 %
warm-electron scattered fraction added back (Ricci+2017 spectral model
adopted in Matsumoto+2026 Eq. B6).

This demo varies ``L_bol`` from 10⁴²–10⁴⁶·⁵ erg/s. The companion example
``plot_xray_nh_sweep.py`` varies the column density at fixed ``L_bol`` to
show the Compton-thin → Compton-thick transition. Reflection (pexrav) and
the 6.4 keV iron Kα line are not modelled here — those are planned in a
follow-up that ports the Magdziarz & Zdziarski 1995 reflection kernel.

References
----------
- Lusso & Risaliti 2016, ApJ 819, 154 (α_ox–L_2500 relation).
- Ricci et al. 2017, Nature 549, 488 (X-ray spectral model).
- Matsumoto et al. 2026 (Eq. B6 of the obscured-AGN fit).
"""

import warnings

import jax.numpy as jnp
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

from tengri.analysis.plotting import setup_style
from tengri.xray import xray_agn_corona_bolometric as xray_agn_corona

setup_style()
warnings.filterwarnings("ignore", message=".*BakedInBackend.*")

wavelength = jnp.logspace(np.log10(0.0124), np.log10(124.0), 512)
wave_keV = 12.398 / np.array(wavelength)

fig, axes = plt.subplots(2, 2, figsize=(12, 8))

# Panel 1: Luminosity sequence (discrete)
ax = axes[0, 0]
log_lbol_vals = np.array([43.0, 44.0, 45.0, 46.0])
for log_lbol in log_lbol_vals:
    l_xray = xray_agn_corona(wavelength, L_agn_bol=10.0**log_lbol)
    ax.loglog(wave_keV, np.array(l_xray), lw=1.4, label=r"$\log L_{\rm bol}=" + f"{log_lbol:.0f}$")

ax.set_xlim(0.1, 1000)
ax.set_ylim(1e22, 1e27)
ax.set_xlabel(r"Energy [keV]")
ax.set_ylabel(r"$\nu L_\nu$ [erg s$^{-1}$]")
ax.text(
    0.05,
    0.95,
    "a) Luminosity sequence",
    transform=ax.transAxes,
    verticalalignment="top",
    fontsize=10,
)
ax.legend(fontsize=9, frameon=False, loc="lower left")

# Panel 2: Spectral features
ax = axes[0, 1]
log_lbol = 44.0
l_xray = xray_agn_corona(wavelength, L_agn_bol=10.0**log_lbol)
ax.loglog(wave_keV, np.array(l_xray), "C0-", lw=2.0)

ax.axvspan(0.5, 2.0, alpha=0.15, color="C1")
ax.axvspan(2.0, 10.0, alpha=0.15, color="C2")

ax.set_xlim(0.1, 1000)
ax.set_ylim(1e22, 1e27)
ax.set_xlabel(r"Energy [keV]")
ax.set_ylabel(r"$\nu L_\nu$ [erg s$^{-1}$]")
ax.text(
    0.05,
    0.95,
    "b) Key spectral features",
    transform=ax.transAxes,
    verticalalignment="top",
    fontsize=10,
)
ax.text(0.8, 0.55e22, "soft band\n(0.5–2 keV)", fontsize=8, color="C1")
ax.text(4.0, 0.55e22, "hard band\n(2–10 keV)", fontsize=8, color="C2")

# Panel 3: Intermediate luminosity range
ax = axes[1, 0]
log_lbol_mid = np.array([45.0, 45.5, 46.0, 46.5])
for log_lbol in log_lbol_mid:
    l_xray = xray_agn_corona(wavelength, L_agn_bol=10.0**log_lbol)
    ax.loglog(wave_keV, np.array(l_xray), lw=1.4, label=r"$\log L_{\rm bol}=" + f"{log_lbol:.1f}$")

ax.set_xlim(0.1, 1000)
ax.set_ylim(1e22, 1e27)
ax.set_xlabel(r"Energy [keV]")
ax.set_ylabel(r"$\nu L_\nu$ [erg s$^{-1}$]")
ax.text(
    0.05,
    0.95,
    "c) Ultra-luminous range",
    transform=ax.transAxes,
    verticalalignment="top",
    fontsize=10,
)
ax.legend(fontsize=9, frameon=False, loc="lower left")

# Panel 4: Full luminosity continuum
ax = axes[1, 1]
log_lbol_range = np.linspace(42.0, 46.5, 12)
norm = mpl.colors.Normalize(vmin=log_lbol_range.min(), vmax=log_lbol_range.max())
cmap = plt.get_cmap("viridis")

for log_lbol in log_lbol_range:
    l_xray = xray_agn_corona(wavelength, L_agn_bol=10.0**log_lbol)
    mask = np.array(l_xray) > 0
    ax.loglog(
        wave_keV[mask], np.array(l_xray)[mask], lw=1.0, color=cmap(norm(log_lbol)), alpha=0.7
    )

ax.set_xlim(0.1, 1000)
ax.set_ylim(1e22, 1e27)
ax.set_xlabel(r"Energy [keV]")
ax.set_ylabel(r"$\nu L_\nu$ [erg s$^{-1}$]")
ax.text(
    0.05, 0.95, "d) Full SED family", transform=ax.transAxes, verticalalignment="top", fontsize=10
)

cbar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax, pad=0.01)
cbar.set_label(r"$\log(L_{\rm bol})$ [erg s$^{-1}$]")

fig.tight_layout()
plt.savefig("plot_xray_agn.png", dpi=150, bbox_inches="tight")
