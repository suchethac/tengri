"""
Diffuse ionized gas suppresses strong optical lines
===================================================

Diffuse ionized gas (DIG) has lower ionization parameter than HII regions,
shifting galaxies toward the LINER region on the BPT diagram. We vary the
DIG fraction from pure HII (0) to mixed gas (0.8).
"""

import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"  # suppress XLA/PjRt C++ INFO+WARNING logs

import warnings

import jax
import jax.numpy as jnp
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

import tengri
from tengri.analysis.plotting import setup_style

setup_style()
warnings.filterwarnings("ignore", message=".*BakedInBackend.*")
warnings.filterwarnings("ignore", message=".*deprecated.*")

ssp = tengri.load_ssp("fsps_prsc_miles_chabrier")
model = tengri.SEDModel.build(
    ssp,
    sfh={
        "type": "dpl",
        "*": tengri.FIXED,
        "alpha": 1.0,
        "beta": 2.5,
        "tau_gyr": 0.3,
        "log_total_mass": 10.0,
    },
    dust={"type": "two_component", "*": tengri.FIXED, "tau_diff": 0.0, "tau_bc": 0.0},
    neb={"type": "cue", "*": tengri.FIXED, "neb_dig_frac": tengri.Uniform(0.0, 0.8)},
    redshift=tengri.Fixed(0.05),
)
baseline = dict(model.spec.sample(jax.random.PRNGKey(0)))

dig_values = np.linspace(0.0, 0.8, 5)
norm = mpl.colors.Normalize(vmin=dig_values.min(), vmax=dig_values.max())
cmap = plt.get_cmap("BuPu")

fig, ax = plt.subplots(figsize=(6.5, 4.2))
for dig in dig_values:
    params = {**baseline, "neb_dig_frac": jnp.float64(dig)}
    out = model.predict_rest_sed(params)
    wave = np.asarray(out.wavelength)
    nu = 2.998e18 / wave
    nu_l_nu = nu * np.asarray(out.sed)
    ax.semilogy(wave, nu_l_nu, color=cmap(norm(dig)), lw=1.4)

ax.set_xlim(4000, 7500)
ax.set_xlabel(r"Rest-frame wavelength $\lambda$ [$\mathrm{\AA}$]")
ax.set_ylabel(r"$\nu L_\nu$  [erg s$^{-1}$]")

cbar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax, pad=0.01)
cbar.set_label(r"DIG fraction")

fig.tight_layout()
plt.savefig("plot_dig_frac_sweep.png", dpi=150, bbox_inches="tight")
