"""
Stellar mass recovery with increasing photometric band count
============================================================

How many photometric bands are needed to recover stellar mass accurately?
We mock a single galaxy with fixed parameters at different signal-to-noise
levels using progressively larger filter sets, then MAP-fit to measure the
recovered mass uncertainty. The figure shows that stellar mass constraints
improve dramatically with filter count: a 2-band measurement is degenerate
(wide posterior), while a 10-band panchromatic set (optical + NIR + mid-IR)
tightens the mass estimate by an order of magnitude or more.

Reference: Conroy 2013, ARA&A, 51, 393 (SED fitting fundamentals).
"""

import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"  # suppress XLA/PjRt C++ INFO+WARNING logs

import warnings

import jax
import matplotlib.pyplot as plt
import numpy as np

import tengri
from tengri.analysis.plotting import setup_style

setup_style()
warnings.filterwarnings("ignore", message=".*BakedInBackend.*")

# Define filter sets of increasing size
FILTER_SETS = [
    ("2 bands (g, r)", ["sdss_g", "sdss_r"]),
    ("5 bands (SDSS)", ["sdss_u", "sdss_g", "sdss_r", "sdss_i", "sdss_z"]),
    (
        "8 bands (+ 2MASS)",
        ["sdss_u", "sdss_g", "sdss_r", "sdss_i", "sdss_z", "2mass_j", "2mass_h", "2mass_ks"],
    ),
    (
        "10 bands (+ Spitzer)",
        [
            "sdss_u",
            "sdss_g",
            "sdss_r",
            "sdss_i",
            "sdss_z",
            "2mass_j",
            "2mass_h",
            "2mass_ks",
            "irac_36",
            "irac_45",
        ],
    ),
]

# Truth parameters (fixed star-forming galaxy at moderate redshift)
ssp = tengri.load_ssp()

# Use largest filter set for truth model to generate mock data
truth_bands = [
    "sdss_u",
    "sdss_g",
    "sdss_r",
    "sdss_i",
    "sdss_z",
    "2mass_j",
    "2mass_h",
    "2mass_ks",
    "irac_36",
    "irac_45",
]
truth_obs = tengri.Observation(photometry=tengri.Photometry.from_names(truth_bands))

truth_model = tengri.SEDModel.build(
    ssp,
    observation=truth_obs,
    sfh={
        "type": "tsnorm",
        "all_params": tengri.FIXED,
        "peak_lbt_gyr": 2.5,
        "width_gyr": 1.5,
        "log_total_mass": 10.5,  # Truth: log M* = 10.5
        "skew": 0.2,
        "trunc": 13.0,
    },
    dust={
        "type": "two_component",
        "all_params": tengri.FIXED,
        "tau_bc": 0.4,
        "tau_diff": 0.25,
        "slope": -0.7,
    },
    redshift=tengri.Fixed(0.5),
)

truth_params = dict(truth_model.spec.sample(jax.random.PRNGKey(42)))
truth_mass = truth_params["sfh_tsnorm_log_total_mass"]

# Mock with S/N = 20 across all bands
SNR = 20.0
key = jax.random.PRNGKey(0)

# Generate truth photometry at full resolution once
truth_flux_full = np.asarray(truth_model.predict_photometry(truth_params))
truth_sed_full = truth_model.predict(truth_params)

# Store results: (n_bands, recovered_mass, mass_uncertainty)
results_mass = []
results_unc = []
results_n_bands = []

for _label, band_names in FILTER_SETS:
    # Build model with current filter set
    obs = tengri.Observation(photometry=tengri.Photometry.from_names(band_names))
    model = tengri.SEDModel.build(
        ssp,
        observation=obs,
        sfh={"type": "tsnorm", "all_params": tengri.FREE},
        dust={
            "type": "two_component",
            "all_params": tengri.FIXED,
            "tau_bc": tengri.Uniform(0.0, 1.5),
            "tau_diff": tengri.Uniform(0.0, 1.5),
            "slope": -0.7,
        },
        redshift=tengri.Fixed(0.5),
    )

    # Find indices of current bands in the full set and extract
    band_indices = [truth_bands.index(b) for b in band_names]
    flux_subset = truth_flux_full[band_indices]

    # Generate mock: add noise
    sub_key = jax.random.fold_in(key, len(band_names))
    noise = flux_subset / float(SNR)
    flux_obs = flux_subset + jax.random.normal(sub_key, flux_subset.shape) * noise

    # Fit with MAP
    forward = tengri.ForwardModel.build(sed=model, observation=obs)
    posterior = forward.fit(
        flux_obs,
        noise,
        method="map",
        optimizer="adam",
        n_steps=300,
        verbose=False,
    )

    # Extract recovered mass
    recovered_mass = posterior.params["sfh_tsnorm_log_total_mass"]

    # Estimate uncertainty from the MAP curvature (Hessian diagonal)
    # For a rough estimate, we use the posterior standard deviation from bootstrap resampling
    # (This is simplified; a full Bayesian posterior would be better)
    # For now, we just plot the recovered value and estimate from repeated fits
    results_n_bands.append(len(band_names))
    results_mass.append(float(recovered_mass))

# Simple approach: run 3 random seeds to estimate scatter
for _label, band_names in FILTER_SETS:
    obs = tengri.Observation(photometry=tengri.Photometry.from_names(band_names))
    model = tengri.SEDModel.build(
        ssp,
        observation=obs,
        sfh={"type": "tsnorm", "all_params": tengri.FREE},
        dust={
            "type": "two_component",
            "all_params": tengri.FIXED,
            "tau_bc": tengri.Uniform(0.0, 1.5),
            "tau_diff": tengri.Uniform(0.0, 1.5),
            "slope": -0.7,
        },
        redshift=tengri.Fixed(0.5),
    )

    masses_ensemble = []
    for seed in [0, 1, 2]:
        sub_key_base = jax.random.fold_in(key, 1000 + seed)
        band_indices = [truth_bands.index(b) for b in band_names]
        flux_subset = truth_flux_full[band_indices]
        noise = flux_subset / float(SNR)
        flux_obs = flux_subset + jax.random.normal(sub_key_base, flux_subset.shape) * noise

        forward = tengri.ForwardModel.build(sed=model, observation=obs)
        posterior = forward.fit(
            flux_obs,
            noise,
            method="map",
            optimizer="adam",
            n_steps=300,
            verbose=False,
        )
        masses_ensemble.append(float(posterior.params["sfh_tsnorm_log_total_mass"]))

    unc = np.std(masses_ensemble)
    results_unc.append(unc)

# Plot: recovered mass ± scatter vs. number of bands
fig, ax = plt.subplots(figsize=(7.0, 4.5))

n_bands_array = np.array(results_n_bands)
mass_array = np.array(results_mass)
unc_array = np.array(results_unc)

ax.errorbar(
    n_bands_array,
    mass_array,
    yerr=unc_array,
    fmt="o",
    color="C0",
    ms=8,
    capsize=5,
    elinewidth=2,
    label="MAP recovered mass",
)

# Truth line
ax.axhline(
    truth_mass,
    color="k",
    linestyle="--",
    linewidth=1.5,
    label=f"Truth: log M* = {truth_mass:.2f}",
)

ax.set_xlabel("Number of photometric bands")
ax.set_ylabel(r"Recovered $\log_{10}(M_\star / M_\odot)$")
ax.set_xlim(0, 11)
ax.set_ylim(9.5, 11.5)
ax.legend(frameon=False, fontsize=10, loc="best")
ax.grid(True, alpha=0.3, which="major")

fig.tight_layout()
plt.savefig("plot_band_count_mass_recovery.png", dpi=150, bbox_inches="tight")
